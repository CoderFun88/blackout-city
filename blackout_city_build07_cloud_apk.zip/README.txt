BLACKOUT CITY — Android project Build 05

Was in diesem Stand verbessert wurde:
- Android-WebView lädt die Spielseite über AndroidX WebViewAssetLoader (HTTPS-App-Origin).
  Das ist die richtige Grundlage für ES-Module; das frühere file://-Problem wird vermieden.
- Hardwarebeschleunigung und Querformat sind aktiviert.
- App hält den Bildschirm beim Spielen an.
- JavaScript, DOM Storage und Web-Audio sind für die Spiel-Demo freigegeben.
- Performance-Optimierungen und RETRO FM aus dem vorherigen Build bleiben enthalten.

Noch nicht erledigt:
- Die Three.js-Datei wird in index.html weiterhin von jsDelivr geladen. Daher braucht der erste Start Internet.
  Die Bibliothek konnte in dieser Arbeitsumgebung nicht heruntergeladen und lokal eingebunden werden.
- Hier sind Android SDK, Build Tools und Gradle nicht installiert. Eine APK kann deshalb hier nicht kompiliert
  oder auf einem echten Gerät getestet werden.

APK erstellen:
1. ZIP entpacken.
2. Projektordner in Android Studio öffnen.
3. Android SDK Platform 35 installieren lassen.
4. Gradle-Synchronisierung abwarten.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
   Alternativ unter Windows build-apk.bat ausführen, wenn Gradle und SDK korrekt eingerichtet sind.
6. APK: app/build/outputs/apk/debug/app-debug.apk

Hinweis:
Build 05 ist ein Android-Studio-Projekt, keine fertige APK. Die Spielmechanik ist weiterhin ein früher
Free-Roam-Prototyp, keine vollständige Open-World-Produktion.
