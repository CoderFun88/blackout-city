@echo off
echo BLACKOUT CITY - Android Debug APK
echo Requires Android Studio / Android SDK 35 and Gradle installed.
gradle assembleDebug
if errorlevel 1 (
  echo Build failed. Open this project in Android Studio and install missing SDK components.
  pause
  exit /b 1
)
echo APK: app\build\outputs\apk\debug\app-debug.apk
pause
