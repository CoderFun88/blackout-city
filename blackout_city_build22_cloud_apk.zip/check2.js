
if (!window.THREE) throw new Error(window.__bcEngineError || 'Three.js UMD fehlt: window.THREE ist nicht verfügbar');
const THREE = window.THREE;
const BC_SRGB = THREE.SRGBColorSpace || THREE.sRGBEncoding;
function bcSetTextureSRGB(texture){
 if ('colorSpace' in texture && THREE.SRGBColorSpace) texture.colorSpace = THREE.SRGBColorSpace;
 else if ('encoding' in texture && THREE.sRGBEncoding !== undefined) texture.encoding = THREE.sRGBEncoding;
 return texture;
}

const scene=new THREE.Scene();
scene.background=new THREE.Color(0x9eb2bf);
scene.fog=new THREE.Fog(0x9fc0d2,190,560);
const camera=new THREE.PerspectiveCamera(62,innerWidth/innerHeight,.1,900);
const renderer=new THREE.WebGLRenderer({antialias:false,powerPreference:'high-performance'});
renderer.setSize(innerWidth,innerHeight);renderer.setPixelRatio(Math.min(devicePixelRatio,1.0));renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.shadowMap.autoUpdate=true;
if ('outputColorSpace' in renderer && THREE.SRGBColorSpace) renderer.outputColorSpace=THREE.SRGBColorSpace; else if (THREE.sRGBEncoding !== undefined) renderer.outputEncoding=THREE.sRGBEncoding; renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.12;
document.body.appendChild(renderer.domElement);

// BUILD 17: animated San-Andreas-style sky dome with clouds, sunset glow, stars and moon.
// BUILD 17 RADAR: compact nearby-world radar for player, vehicles and police.
const skyUniforms={uTime:{value:0},uDay:{value:1}};
const skyGeo=new THREE.SphereGeometry(700,32,20);
const skyMat=new THREE.ShaderMaterial({side:THREE.BackSide,depthWrite:false,uniforms:skyUniforms,vertexShader:`varying vec3 vDir; void main(){vDir=normalize(position);gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}`,fragmentShader:`uniform float uTime; uniform float uDay; varying vec3 vDir;
float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.0-2.0*f);return mix(mix(hash(i),hash(i+vec2(1.,0.)),f.x),mix(hash(i+vec2(0.,1.)),hash(i+vec2(1.,1.)),f.x),f.y);}
void main(){float h=clamp(vDir.y*.5+.5,0.,1.);vec3 night=vec3(.012,.025,.075),horizonNight=vec3(.08,.12,.22);vec3 day=vec3(.20,.48,.78),horizonDay=vec3(.92,.66,.43);vec3 col=mix(mix(horizonNight,night,smoothstep(.02,.95,h)),mix(horizonDay,day,smoothstep(.02,.95,h)),uDay);float cloudN=noise(vec2(vDir.x*13.0+uTime*.004,vDir.z*13.0+vDir.y*4.0));float cloud=smoothstep(.60,.78,cloudN)*smoothstep(-.08,.42,vDir.y);vec3 cloudDay=vec3(.96,.91,.82),cloudNight=vec3(.20,.25,.36);col=mix(col,mix(cloudNight,cloudDay,uDay),cloud*.56);float star=step(.9975,hash(floor(vDir.xz*500.0)))*smoothstep(.18,.65,1.0-uDay)*smoothstep(-.02,.25,vDir.y);col+=vec3(.75,.84,1.0)*star;float glow=exp(-length(vDir-normalize(vec3(-.35,.30,.72)))*18.0);col+=vec3(1.0,.57,.28)*glow*(.22+.45*(1.0-uDay));gl_FragColor=vec4(col,1.0);}`});
const skyDome=new THREE.Mesh(skyGeo,skyMat);skyDome.frustumCulled=false;scene.add(skyDome);
const sunDisc=new THREE.Mesh(new THREE.SphereGeometry(10,20,16),new THREE.MeshBasicMaterial({color:0xffd49a}));scene.add(sunDisc);
const moonDisc=new THREE.Mesh(new THREE.SphereGeometry(6.5,20,16),new THREE.MeshBasicMaterial({color:0xe0e9f6}));scene.add(moonDisc);

scene.add(new THREE.HemisphereLight(0xf1e8d5,0x65714e,1.9));
const sun=new THREE.DirectionalLight(0xffe3bd,2.25);sun.position.set(-90,140,70);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);sun.shadow.camera.left=-190;sun.shadow.camera.right=190;sun.shadow.camera.top=190;sun.shadow.camera.bottom=-190;sun.shadow.camera.near=1;sun.shadow.camera.far=420;sun.shadow.bias=-0.00035;scene.add(sun);
const M=(c,r=.84,metal=0)=>new THREE.MeshStandardMaterial({color:c,roughness:r,metalness:metal});
const mats={
 grass:M(0x667653),road:M(0x34383a),sidewalk:M(0xb1a99a),curb:M(0xd1c5ac),
 lane:M(0xe7d5a7),glass:M(0x31576a,.22,.12),windowLit:new THREE.MeshStandardMaterial({color:0xf5c77d,emissive:0xd18a38,emissiveIntensity:.24,roughness:.5}),
 dark:M(0x1a2025),rubber:M(0x111416),trunk:M(0x604936),leaf:M(0x426344),
 lamp:M(0xffd69a,.4),white:M(0xf0e6cf),stucco:M(0xc7ae88),brick:M(0x986d56),
 roof:M(0x6e6254),concrete:M(0x8e897d),sign:M(0xd9b66f)
};
function box(parent,x,y,z,w,h,d,mat){const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat);m.position.set(x,y,z);parent.add(m);return m;}
function shadow(mesh,cast=true,receive=true){mesh.castShadow=cast;mesh.receiveShadow=receive;return mesh;}
function seeded(seed){return ()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296}}
const rand=seeded(8707);
shadow(box(scene,0,-.32,0,640,.5,640,mats.grass),false,true);
// Fine asphalt grain and concrete mottling, generated locally for crisp close-up detail.
function noiseTexture(base,seed=1){const c=document.createElement('canvas');c.width=c.height=256;const g=c.getContext('2d');g.fillStyle=base;g.fillRect(0,0,256,256);let q=seed;for(let i=0;i<5200;i++){q=(q*1664525+1013904223)>>>0;const x=q/4294967296*256;q=(q*1664525+1013904223)>>>0;const y=q/4294967296*256;const a=.025+(q%100)/2200;g.fillStyle=`rgba(255,255,255,${a})`;g.fillRect(x,y,1+(q%3),1+(q%2));}const t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(8,8);bcSetTextureSRGB(t);return t;}
mats.road.map=noiseTexture('#34383a',17);mats.road.needsUpdate=true;mats.sidewalk.map=noiseTexture('#b1a99a',31);mats.sidewalk.needsUpdate=true;


// BUILD 15 VISUAL PASS: authored procedural storefront signage, wet-road reflections and urban decals.
function makeStoreSign(label,accent=0xffb45e){
 const c=document.createElement('canvas');c.width=512;c.height=128;const x=c.getContext('2d');
 x.fillStyle='#111b24';x.fillRect(0,0,512,128);
 x.fillStyle='#293a43';x.fillRect(7,7,498,114);
 x.strokeStyle='#d6b16e';x.lineWidth=5;x.strokeRect(8,8,496,112);
 x.font='900 56px Arial';x.textAlign='center';x.textBaseline='middle';
 x.shadowColor='#ffb45e';x.shadowBlur=18;x.fillStyle='#f3d49b';x.fillText(label,256,67,470);
 const tex=new THREE.CanvasTexture(c);bcSetTextureSRGB(tex);
 return new THREE.MeshBasicMaterial({map:tex,side:THREE.DoubleSide});
}
const shopNames=['LIQUOR','MARKET 24/7','PAWN SHOP','DINER','AUTO REPAIR','TATTOO','MOTEL','BARBER'];
function neonTube(parent,x,y,z,w,label,color=0xff8058){
 const mat=new THREE.MeshStandardMaterial({color,emissive:color,emissiveIntensity:.9,roughness:.28});
 const sign=box(parent,x,y,z,w,.22,.12,mat);
 const labelMat=makeStoreSign(label,color);
 const panel=new THREE.Mesh(new THREE.PlaneGeometry(w*.94,.78),labelMat);
 panel.position.set(x,y+.62,z+.08);parent.add(panel);
}
function addWetPatches(){
 const puddleMat=new THREE.MeshPhysicalMaterial({color:0x52616a,roughness:.16,metalness:.28,transparent:true,opacity:.36,clearcoat:1,clearcoatRoughness:.08,depthWrite:false});
 for(let i=0;i<90;i++){
  const x=(rand()-.5)*570,z=(rand()-.5)*570;
  if(Math.abs((x%84))<10||Math.abs((z%84))<10)continue;
  const geo=new THREE.CircleGeometry(.5+rand()*2.6,12);
  const m=new THREE.Mesh(geo,puddleMat);m.rotation.x=-Math.PI/2;m.position.set(x,.033,z);m.scale.set(1.1+rand()*2.8,.55+rand()*1.4,1);m.material=puddleMat;scene.add(m);
 }
}
addWetPatches();

// 7 x 7 street grid, with wide avenues and marked intersections.
const roadLines=[];for(let i=-3;i<=3;i++)roadLines.push(i*84);
for(const p of roadLines){
 shadow(box(scene,p,-.035,0,18,.12,610,mats.road),false,true);
 shadow(box(scene,0,-.035,p,610,.12,18,mats.road),false,true);
 // dashed lane markings
 for(let z=-290;z<=290;z+=18){box(scene,p-3,.035,z, .16,.025,7,mats.lane);box(scene,p+3,.035,z,.16,.025,7,mats.lane)}
 for(let x=-290;x<=290;x+=18){box(scene,x,.035,p-3,7,.025,.16,mats.lane);box(scene,x,.035,p+3,7,.025,.16,mats.lane)}
}
// sidewalks along road edges
for(const p of roadLines){
 for(const side of [-1,1]){
  box(scene,p+side*12,.02,0,5,.22,610,mats.sidewalk);
  box(scene,0,.02,p+side*12,610,.22,5,mats.sidewalk);
 }
}

// Curbs, storm drains and parking bays add scale cues along downtown streets.
for(const p of roadLines){
 for(const side of [-1,1]){
  box(scene,p+side*9.25,.12,0,.42,.24,610,mats.curb);
  box(scene,0,.12,p+side*9.25,610,.24,.42,mats.curb);
  for(let q=-280;q<280;q+=42){
   box(scene,p+side*11.4,.145,q,1.1,.045,2.4,M(0x41494a));
   box(scene,q,.145,p+side*11.4,2.4,.045,1.1,M(0x41494a));
  }
 }
}

// Crosswalk bars at selected intersections
for(let ix=-2;ix<=2;ix++)for(let iz=-2;iz<=2;iz++){
 const x=ix*84,z=iz*84;
 for(let k=-4;k<=4;k++){
  box(scene,x+k*1.45,.05,z-8, .82,.035,4.2,mats.white);
  box(scene,x-8,.05,z+k*1.45,4.2,.035,.82,mats.white);
 }
}

// buildings: multiple footprints in each city block, detailed shopfronts and rooftop units
const facades=[0x68727a,0x857b6b,0x52616b,0x958c7b,0x4a5962,0x78675f,0x777f7b,0x6b6a78].map(c=>M(c));
const trim=M(0x303a40),awning=[0x9d493b,0x315d76,0xb08a4b,0x456b54].map(c=>M(c));

// Procedural facade textures: subtle stucco grain, painted panels and repeated windows.
function facadeTexture(base, accent, seed=1){
 const c=document.createElement('canvas');c.width=256;c.height=256;const x=c.getContext('2d');
 x.fillStyle=base;x.fillRect(0,0,256,256);
 let s=seed;const rnd=()=>{s=(s*1664525+1013904223)>>>0;return s/4294967296};
 for(let i=0;i<1700;i++){const v=Math.floor(rnd()*28);x.fillStyle=`rgba(${v},${v},${v},0.11)`;x.fillRect(rnd()*256,rnd()*256,1+rnd()*3,1+rnd()*3)}
 for(let y=18;y<256;y+=42){
  for(let xx=14;xx<256;xx+=39){
   x.fillStyle='#263f4b';x.fillRect(xx,y,25,28);
   x.fillStyle='rgba(170,207,218,.32)';x.fillRect(xx+2,y+2,10,24);
   x.fillStyle=accent;x.fillRect(xx-2,y+29,29,3);
  }
 }
 const t=new THREE.CanvasTexture(c);bcSetTextureSRGB(t);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.anisotropy=4;return t;
}
const facadeTex=[
 facadeTexture('#c9b28e','#876f54',12),
 facadeTexture('#b6a18a','#6c5848',29),
 facadeTexture('#a7b0a9','#657a76',44),
 facadeTexture('#c6a18a','#8b5948',67),
 facadeTexture('#b8b5a8','#716b5d',83)
];
const texturedMats=facadeTex.map(t=>new THREE.MeshStandardMaterial({map:t,roughness:.93}));
const buildings=[];
function makeBuilding(x,z,w,d,h,style){
 const g=new THREE.Group();g.position.set(x,0,z);scene.add(g);
 const body=shadow(box(g,0,h/2,0,w,h,d,texturedMats[Math.floor(rand()*texturedMats.length)]),true,true);
 const base=box(g,0,1.5,0,w+.35,3,d+.35,trim);base.position.y=1.5;
 const floors=Math.max(2,Math.floor((h-4)/3.5));
 for(let f=0;f<floors;f++){
  const y=4+f*3.45;
  for(let xx=-w/2+2;xx<w/2-1;xx+=3.2){
   const win=box(g,xx,y,d/2+.055,1.55,1.85,.09,rand()>.8?mats.windowLit:mats.glass);
   box(g,xx,y-1.02,d/2+.11,1.65,.12,.12,trim);
   box(g,xx,y+1.02,d/2+.11,1.65,.12,.12,trim);
   box(g,xx,y,-d/2-.055,1.55,1.85,.09,mats.glass);
  }
  for(let zz=-d/2+2;zz<d/2-1;zz+=3.2){
   box(g,w/2+.055,y,zz,.09,1.85,1.55,mats.glass);
   box(g,-w/2-.055,y,zz,.09,1.85,1.55,mats.glass);
  }
 }
 // storefront, large glass bays and colored canopy
 if(style==='shop'){
  for(let xx=-w/2+2.4;xx<w/2-1;xx+=4.6){
   box(g,xx,2.1,d/2+.16,3.65,2.5,.12,mats.glass);
   box(g,xx,3.42,d/2+.24,4.1,.22,.42,awning[Math.floor(rand()*awning.length)]);
  }
  box(g,0,4.25,d/2+.23,Math.min(w-3,13),.8,.3,M(0x202a31));
  box(g,0,4.25,d/2+.4,Math.min(w-4,12),.12,.08,M(0xe6c47e));
 }else{
  // parapet and rooftop mechanical equipment
  box(g,0,h+.55,0,w+.8,1.1,d+.8,trim);
  box(g,0,h+1.12,0,w+.35,.14,d+.35,M(0xb7aa92));
  // rooftop water tank / vents add a recognizable skyline silhouette
  const tank=box(g,(rand()-.5)*w*.42,h+2.2,(rand()-.5)*d*.42,2.2,2.0,2.2,M(0x777c79));
  const tankTop=box(g,tank.position.x,h+3.25,tank.position.z,2.25,.16,2.25,M(0x343b3d));
  for(let n=0;n<2;n++){
   const unit=box(g,(rand()-.5)*w*.45,h+1.5,(rand()-.5)*d*.45,2.4,1.8,2.4,M(0x737a7c));
   box(g,unit.position.x,h+2.45,unit.position.z,2.1,.12,2.1,M(0x353d41));
  }
 }
 // occasional balconies, railings and exterior AC units
 if(style==='office' && h>25){
  for(let fy=8;fy<h-4;fy+=9){
   box(g,0,fy,d/2+.85,Math.min(w-2,9),.16,1.45,M(0x8d887e));
   box(g,0,fy+.65,d/2+1.48,Math.min(w-2,9),.12,.12,M(0x454b4d));
   for(let bx=-Math.min(w-2,9)/2;bx<=Math.min(w-2,9)/2;bx+=.65)box(g,bx,fy+.36,d/2+1.48,.045,.55,.045,M(0x454b4d));
  }
 }
 // corner vertical trim and entrance
 box(g,0,1.55,d/2+.2,2.2,3.1,.18,M(0x252f35));
 box(g,0,1.45,d/2+.32,1.15,2.8,.1,M(0x193442,.3));
 // Real-world style facade dressing: sign band, window awnings, AC units and fire-escape rails.
 if(style==='shop'){
  const signMat=M([0x263d4b,0x6c3028,0x314d3e,0x80623a][Math.floor(rand()*4)],.65);
  box(g,0,4.35,d/2+.48,Math.min(w-2,15),.92,.22,signMat);
  box(g,0,4.35,d/2+.61,Math.min(w-3,13),.075,.035,M(0xe5c27b,.45));
  const shopLabel=shopNames[Math.floor(rand()*shopNames.length)];
  const faceSign=new THREE.Mesh(new THREE.PlaneGeometry(Math.min(w-4,12),.72),makeStoreSign(shopLabel));
  faceSign.position.set(0,4.55,d/2+.78);g.add(faceSign);
  if(rand()>.45)neonTube(g,0,5.2,d/2+.72,Math.min(w-4,9),shopLabel,rand()>.5?0xff704d:0x55c8d8);
  // Window mullions and door handles make shopfronts read as real street-level businesses.
  for(let sx=-w/2+2.8;sx<w/2-1;sx+=4.6){box(g,sx,2.1,d/2+.245,.08,2.4,.08,trim);box(g,sx+1.4,1.35,d/2+.30,.08,.22,.07,chrome);}

  for(let ax=-w/2+2;ax<w/2-1;ax+=5.5){box(g,ax,3.1,d/2+.62,3.6,.12,.72,awning[Math.floor(rand()*awning.length)]);}
 }else{
  for(let fy=7;fy<h-3;fy+=Math.max(9,Math.floor(h/22)*3)){
   const ax=-w/2+1.2+rand()*(w-3);
   box(g,ax,fy,d/2+.18,1.0,.65,.38,M(0x7b8585,.8));
   box(g,ax,fy+.36,d/2+.39,1.04,.08,.08,trim);
  }
  if(h>24){
   // narrow exterior fire escape on one side
   const side=rand()>.5?1:-1;const fx=side*(w/2+.48);
   for(let fy=8;fy<h-5;fy+=7){box(g,fx,fy,d*.20,1.0,.12,3.8,M(0x555e60,.65,.35));box(g,fx,fy+.58,d*.20,1.0,.10,.10,chrome);for(let q=-1.5;q<=1.5;q+=.5)box(g,fx,fy+.30,d*.20+q,.055,.48,.055,chrome);}
  }
 }
 buildings.push({x,z,w,d,h});
 return g;
}
for(let bx=-3;bx<3;bx++)for(let bz=-3;bz<3;bz++){
 const cx=bx*84+42,cz=bz*84+42;
 const n=2+Math.floor(rand()*2);
 for(let j=0;j<n;j++){
  const w=18+rand()*13,d=17+rand()*12;
  const x=cx+(j%2===0?-15:15)+(rand()-.5)*4;
  const z=cz+(j<2?-14:15)+(rand()-.5)*4;
  const h=(Math.abs(bx)+Math.abs(bz)<2?24:12)+rand()*48;
  makeBuilding(x,z,w,d,h,rand()>.55?'shop':'office');
 }
}



// Downtown landmarks: three distinct skyline towers with stepped crowns and illuminated crown bands.
function landmarkTower(x,z,w,d,h,bodyColor,topColor){
 const g=new THREE.Group();g.position.set(x,0,z);scene.add(g);
 const bodyMat=M(bodyColor,.72,.18),edge=M(0x343f46,.55,.4),lit=new THREE.MeshStandardMaterial({color:0xffd99a,emissive:0xb97b35,emissiveIntensity:.38,roughness:.35});
 box(g,0,h/2,0,w,h,d,bodyMat);
 for(let y=5;y<h-3;y+=4.2)for(let xx=-w/2+1.8;xx<w/2-1;xx+=2.8){
  box(g,xx,y,d/2+.035,1.25,2.15,.06,rand()>.72?lit:mats.glass);
  box(g,xx,y,-d/2-.035,1.25,2.15,.06,mats.glass);
 }
 box(g,0,h+1,0,w+1,2,d+1,edge);box(g,0,h+2.1,0,w*.68,.35,d*.68,M(topColor,.48,.32));
 for(let i=0;i<4;i++)box(g,0,h+3.3+i*.55,0,w*.4-i*.8,.12,d*.4-i*.8,edge);
 buildings.push({x,z,w,d,h});
}
landmarkTower(-42,-42,22,24,78,0x66757b,0xc3b69e);
landmarkTower(42,42,24,22,92,0x596a73,0xb7c4c4);
landmarkTower(-126,42,20,22,64,0x877a68,0xc8b58e);


// Rooftop aviation beacons and a few illuminated vertical office signs.
const rooftopBeacons=[];
for(const b of buildings){
 if(b.h>42){
  const beacon=new THREE.Mesh(new THREE.SphereGeometry(.20,8,6),new THREE.MeshBasicMaterial({color:0xff3434,transparent:true,opacity:1}));
  beacon.position.set(b.x,b.h+3.4,b.z);scene.add(beacon);rooftopBeacons.push(beacon);
 }
}

// Low-rise California-style homes around the edge of the downtown grid.
const houseColors=[0xd7bd98,0xc7a78a,0xd9d0b9,0xb9b4a0].map(c=>M(c));
for(let i=0;i<24;i++){
 const side=i%4, n=Math.floor(i/4), x=(side<2?-1:1)*(310+n*15), z=(side%2===0?-1:1)*(80+n*42);
 const g=new THREE.Group();g.position.set(x,0,z);scene.add(g);
 const w=13+rand()*4,d=11+rand()*4,h=5.5+rand()*1.5;
 box(g,0,h/2,0,w,h,d,houseColors[i%houseColors.length]);
 const roof=new THREE.Mesh(new THREE.ConeGeometry(w*.76,3.2,4),M(0x795a48));roof.position.y=h+1.5;roof.rotation.y=Math.PI/4;g.add(roof);
 box(g,0,1.55,d/2+.08,2.1,3.1,.15,M(0x554638));
 for(let s of [-1,1])box(g,s*3.5,2.2,d/2+.09,2.4,1.8,.12,mats.glass);
 box(g,0,.15,d/2+4,w+5,.25,7,M(0x99948a));
}


// Extra street-level details: dumpsters, hydrants, utility cabinets and benches.
function streetProp(x,z,type=0){const g=new THREE.Group();g.position.set(x,0,z);scene.add(g);if(type===0){box(g,0,.55,0,1.5,1.1,1.05,M(0x53645a));box(g,0,1.12,0,1.58,.12,1.1,trim);for(let k=-1;k<=1;k++)box(g,k*.42,.22,.55,.12,.25,.04,trim)}else if(type===1){const base=new THREE.Mesh(new THREE.CylinderGeometry(.22,.28,.8,10),M(0xb33f35));base.position.y=.4;g.add(base);const cap=new THREE.Mesh(new THREE.CylinderGeometry(.28,.28,.12,10),M(0xb33f35));cap.position.y=.83;g.add(cap)}else{box(g,0,.48,0,1.8,.12,.55,M(0x765a3e));for(const xx of [-.7,.7])box(g,xx,.23,0,.1,.5,.1,trim)}return g;}
for(let i=0;i<34;i++){const x=(Math.floor(rand()*6)-3)*84+(rand()-.5)*52;const z=(Math.floor(rand()*6)-3)*84+(rand()-.5)*52;streetProp(x,z,i%3)}
// Subtle rooftop aerials and water-tank legs give the skyline more believable silhouettes.
for(const b of buildings){if(b.h>30){const aerial=new THREE.Mesh(new THREE.CylinderGeometry(.035,.055,3.2,6),M(0x45494a));aerial.position.set(b.x+(rand()-.5)*b.w,b.h+2.7,b.z+(rand()-.5)*b.d);aerial.castShadow=true;scene.add(aerial);}}

// Street furniture: lamps, trees, bins, benches and traffic signals.
function streetLamp(x,z,rot=0){
 const g=new THREE.Group();g.position.set(x,0,z);g.rotation.y=rot;scene.add(g);
 box(g,0,3.1,0,.22,6.2,.22,M(0x30383b));
 box(g,.9,6.0,0,2,.16,.18,M(0x30383b));
 const glow=box(g,1.7,5.88,0,.85,.22,.55,new THREE.MeshStandardMaterial({color:0xffe4ad,emissive:0xffb85c,emissiveIntensity:1.15,roughness:.3}));
}

const nightLights=[];
for(let ix=-2;ix<=2;ix+=2)for(let iz=-2;iz<=2;iz++){
 const light=new THREE.PointLight(0xffc98b,0,30,2);
 light.position.set(ix*84+13,5.5,iz*84+13);scene.add(light);nightLights.push(light);
}
for(let ix=-3;ix<=3;ix++)for(let iz=-3;iz<=3;iz++){
 const x=ix*84,z=iz*84;
 streetLamp(x+13,z+13);
 if((ix+iz)%2===0)streetLamp(x-13,z-13,Math.PI);
}
function tree(x,z){
 const g=new THREE.Group();g.position.set(x,0,z);scene.add(g);
 shadow(box(g,0,1.5,0,.55,3,.55,mats.trunk),true,true);
 for(let k=0;k<5;k++){const crown=new THREE.Mesh(new THREE.IcosahedronGeometry(1.55+rand()*.55,2),M([0x31583b,0x426b43,0x58784a,0x365d42][k%4],.9));crown.castShadow=true;crown.receiveShadow=true;crown.position.set((rand()-.5)*2,2.9+rand()*1.5,(rand()-.5)*2);g.add(crown)}
}

function palm(x,z){
 const g=new THREE.Group();g.position.set(x,0,z);scene.add(g);
 const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.22,.42,8,8),M(0x8b6945));trunk.castShadow=true;trunk.receiveShadow=true;trunk.position.y=4;trunk.rotation.z=.035;g.add(trunk);
 for(let i=0;i<9;i++){
  const a=i*Math.PI*2/9,frond=new THREE.Group();frond.rotation.y=a;frond.position.y=7.7;g.add(frond);
  const stem=box(frond,0,0,2.1,.11,.11,4.3,M(0x587447));stem.rotation.x=-.08;
  for(let j=0;j<7;j++){const zf=.6+j*.48;const leaf=box(frond,(j%2?-.45:.45),-.18,zf,.08,.08,1.05,M(0x4f7545));leaf.rotation.y=(j%2?-.5:.5);leaf.rotation.x=-.35}
 }
}
for(let bx=-3;bx<3;bx++)for(let bz=-3;bz<3;bz++){
 const cx=bx*84+42,cz=bz*84+42;
 for(let i=0;i<3;i++){tree(cx-27+i*27,cz-27);tree(cx-27+i*27,cz+27)}
 if((bx+bz)%2===0){palm(cx-31,cz-12);palm(cx+31,cz+12)}
}


// BUILD 16: original CC0-style procedural assets (generated from geometry, no third-party model files).
// Traffic lights at the main intersections. Signals cycle independently with visible red/amber/green lenses.
const trafficSignals=[];
const signalHousing=M(0x20272a,.72),signalPole=M(0x394347,.65,.35);
const signalLenses=[
 new THREE.MeshStandardMaterial({color:0xff3434,emissive:0xb90000,emissiveIntensity:1.5}),
 new THREE.MeshStandardMaterial({color:0xffc43b,emissive:0xa96800,emissiveIntensity:1.2}),
 new THREE.MeshStandardMaterial({color:0x42e477,emissive:0x087b31,emissiveIntensity:1.2})
];
function trafficLight(x,z,rot=0){
 const g=new THREE.Group();g.position.set(x,0,z);g.rotation.y=rot;scene.add(g);
 const pole=new THREE.Mesh(new THREE.CylinderGeometry(.10,.14,5.8,8),signalPole);pole.position.y=2.9;pole.castShadow=true;g.add(pole);
 box(g,.0,5.35,0,.9,2.05,.48,signalHousing);
 const lamps=[];
 for(let i=0;i<3;i++){
  const bulb=new THREE.Mesh(new THREE.SphereGeometry(.17,12,10),signalLenses[i]);bulb.position.set(0,6.05-i*.66,.255);g.add(bulb);lamps.push(bulb);
 }
 box(g,.0,6.48,0,1.05,.12,.58,signalPole);
 trafficSignals.push({lamps,offset:rand()*12});
}
for(let ix=-2;ix<=2;ix++)for(let iz=-2;iz<=2;iz++){
 const x=ix*84,z=iz*84;
 trafficLight(x-10,z-10,0);trafficLight(x+10,z+10,Math.PI);
}
// Beach district at the northern coast: sand, ocean, surf edge, promenade, lifeguard hut and loungers.
const oceanMat=new THREE.MeshStandardMaterial({color:0x176b91,roughness:.28,metalness:.12});
const sandMat=M(0xd9bd83,.96),foamMat=new THREE.MeshBasicMaterial({color:0xe8e5d5,transparent:true,opacity:.72});
const sea=new THREE.Mesh(new THREE.PlaneGeometry(760,300,1,1),oceanMat);sea.rotation.x=-Math.PI/2;sea.position.set(0,-.20,-455);scene.add(sea);
const sand=new THREE.Mesh(new THREE.PlaneGeometry(760,92),sandMat);sand.rotation.x=-Math.PI/2;sand.position.set(0,-.12,-270);scene.add(sand);
const promenade=new THREE.Mesh(new THREE.PlaneGeometry(760,13),M(0xb9aa91,.88));promenade.rotation.x=-Math.PI/2;promenade.position.set(0,-.035,-222);scene.add(promenade);
const surf=new THREE.Mesh(new THREE.PlaneGeometry(760,3),foamMat);surf.rotation.x=-Math.PI/2;surf.position.set(0,-.055,-315);scene.add(surf);
for(let i=0;i<28;i++){
 const x=-340+i*25;
 // low beach wall / promenade lights
 box(scene,x,.35,-228,12,.7,.5,M(0x8d897d));
 if(i%2===0)streetLamp(x,-237,Math.PI/2);
 // beach parasol and two sun loungers
 const px=x+(rand()-.5)*8,pz=-270-rand()*30;
 const pole=new THREE.Mesh(new THREE.CylinderGeometry(.055,.055,2.2,7),M(0xddd3c0));pole.position.set(px,1.1,pz);scene.add(pole);
 const canopy=new THREE.Mesh(new THREE.ConeGeometry(1.45,.62,10),M([0xe8e0ce,0x3d83a0,0xd15a45,0xe4bd63][i%4]));canopy.position.set(px,2.25,pz);scene.add(canopy);
 for(let k=0;k<2;k++){const lounger=box(scene,px+(k?1.9:-1.9),.28,pz+2,.9,.18,2.1,M(k?0x3c6f83:0xe4d5b9));lounger.rotation.x=-.08;}
}
// Lifeguard hut, beach access kiosks and coastal palms.
const hut=new THREE.Group();hut.position.set(-38,0,-255);scene.add(hut);
box(hut,0,1.5,0,7,3.0,5,M(0xe7d5b2));box(hut,0,3.35,0,7.8,.45,5.8,M(0xb84d39));
box(hut,0,2.0,2.56,2.3,1.6,.12,M(0x24516a));box(hut,0,3.05,0,8,.12,6,M(0xeee0c4));
for(let i=0;i<12;i++)palm(-330+i*60,-245+(i%2)*20);
// Flock of birds with animated articulated wings, silhouetted against the sky.
const birdFlock=[];
function makeBird(x,y,z,scale=1){
 const g=new THREE.Group();g.position.set(x,y,z);g.scale.setScalar(scale);scene.add(g);
 const feather=M(0x202b32,.8),body=new THREE.Mesh(new THREE.SphereGeometry(.18,8,6),feather);body.scale.set(1,.55,1.5);g.add(body);
 const wings=[];
 for(const side of [-1,1]){
  const pivot=new THREE.Group();pivot.position.set(side*.12,.02,0);g.add(pivot);
  const wing=box(pivot,side*.52,0,0,1.05,.055,.22,feather);wing.rotation.z=side*.12;wings.push({pivot,side});
 }
 birdFlock.push({g,wings,phase:rand()*6,speed:2+rand()*1.6,baseY:y});
}
for(let i=0;i<11;i++)makeBird(-150+rand()*300,32+rand()*28,-80-rand()*190,.65+rand()*.45);
// Downtown street-level detail: bus shelters, parking meters, bins, hydrants and storefront awnings.
function busShelter(x,z,rot=0){
 const g=new THREE.Group();g.position.set(x,0,z);g.rotation.y=rot;scene.add(g);
 const metal=M(0x454f52,.5,.55),glassPanel=new THREE.MeshPhysicalMaterial({color:0x9dbbc1,transparent:true,opacity:.28,roughness:.15,metalness:.1});
 for(const xx of [-2.2,2.2]){box(g,xx,1.35,0,.12,2.7,.12,metal);box(g,xx,2.75,0,.12,.12,3.8,metal)}
 box(g,0,2.68,0,4.6,.12,3.8,glassPanel);box(g,0,.62,0,3.4,.18,.65,M(0x37464a));
 box(g,-1.5,1.8,.08,.8,.65,.08,M(0x284d60));
}
for(let i=-2;i<=2;i++){busShelter(i*84+18, -18,0);busShelter(i*84-18,102,Math.PI/2)}
for(let i=0;i<30;i++){
 const x=(Math.floor(rand()*6)-3)*84+(rand()-.5)*26,z=(Math.floor(rand()*6)-3)*84+(rand()-.5)*26;
 const bin=new THREE.Mesh(new THREE.CylinderGeometry(.34,.4,1.0,10),M(0x40545a));bin.position.set(x,.5,z);scene.add(bin);
 const lid=new THREE.Mesh(new THREE.CylinderGeometry(.38,.38,.09,10),M(0x242d31));lid.position.set(x,1.04,z);scene.add(lid);
}
// End BUILD 16 additions.

// A more recognizable third-person character with torso, arms, legs and animated gait.
function makePerson(x,z,shirt=0x354f68){
 const g=new THREE.Group();g.position.set(x,0,z);scene.add(g);
 const skin=M(0xc89a79),cloth=M(shirt),pants=M(0x252d36),shoe=M(0x171b20);
 const torso=box(g,0,1.32,0,.72,.9,.38,cloth);
 const head=new THREE.Mesh(new THREE.SphereGeometry(.25,16,12),skin);head.position.y=2.05;g.add(head);head.castShadow=true;
 const hair=new THREE.Mesh(new THREE.SphereGeometry(.255,10,8),M(0x302722));hair.scale.set(1,.48,1);hair.position.set(0,2.22,0);g.add(hair);
 const arms=[],legs=[];
 for(const side of [-1,1]){
  const arm=new THREE.Group();arm.position.set(side*.48,1.63,0);g.add(arm);
  box(arm,0,-.34,0,.2,.72,.22,cloth);const hand=new THREE.Mesh(new THREE.SphereGeometry(.12,8,8),skin);hand.position.y=-.72;arm.add(hand);arms.push(arm);
  const leg=new THREE.Group();leg.position.set(side*.2,.88,0);g.add(leg);
  box(leg,0,-.35,0,.25,.75,.28,pants);box(leg,0,-.76,-.08,.28,.16,.42,shoe);legs.push(leg);
 }
 return {group:g,arms,legs};
}
const playerObj=makePerson(0,12,0x355b7c),player=playerObj.group;
let pedestrians=[];
for(let i=0;i<42;i++){
 const x=(Math.floor(rand()*6)-3)*84+(rand()-.5)*58;
 const z=(Math.floor(rand()*6)-3)*84+(rand()-.5)*58;
 pedestrians.push({obj:makePerson(x,z,[0x8c493d,0x4b6d59,0x77718a,0xb18b51,0x3f637b][i%5]),phase:rand()*6,speed:1+rand()*1.1,dir:rand()*Math.PI*2});
}

// Vehicle models with cabin, windows, lights, wheels and bumpers.
const cars=[],traffic=[];
function makeCar(color,x,z,rot=0,policeCar=false){
 const g=new THREE.Group();scene.add(g);g.position.set(x,0,z);g.rotation.y=rot;
 const paint=M(color,.32,.18),glass=new THREE.MeshPhysicalMaterial({color:0x203746,roughness:.16,metalness:.25,clearcoat:.9,clearcoatRoughness:.12}),chrome=M(0xaeb8bb,.24,.82),rubber=M(0x101214,.92),rim=M(0x9da6a9,.3,.78);
 box(g,0,.62,0,2.18,.72,4.55,paint);box(g,0,.91,-1.48,2.12,.30,1.35,paint);box(g,0,.91,1.52,2.12,.30,1.22,paint);box(g,0,1.18,-.20,1.78,.68,2.25,paint);
 const fw=box(g,0,1.31,-1.17,1.68,.48,.075,glass);fw.rotation.x=-.42;const rw=box(g,0,1.31,.82,1.68,.48,.075,glass);rw.rotation.x=.42;box(g,0,1.58,-.18,1.82,.10,2.28,paint);
 for(const side of [-1,1]){box(g,side*.91,1.24,-.18,.055,.54,2.05,glass);for(const zz of [-1.25,-.15,.82])box(g,side*.94,1.25,zz,.10,.62,.075,paint);box(g,side*1.095,.69,-.05,.10,.48,1.55,paint);box(g,side*1.15,.88,-.10,.07,.055,.28,chrome);box(g,side*1.12,.38,0,.10,.16,3.65,chrome);box(g,side*1.12,1.30,-1.02,.25,.13,.25,paint);
 for(const zz of [-1.43,1.43]){const wg=new THREE.Group();wg.position.set(side*1.08,.39,zz);g.add(wg);const tire=new THREE.Mesh(new THREE.CylinderGeometry(.39,.39,.25,20),rubber);tire.rotation.z=Math.PI/2;wg.add(tire);const alloy=new THREE.Mesh(new THREE.CylinderGeometry(.255,.255,.265,16),rim);alloy.rotation.z=Math.PI/2;wg.add(alloy);const hub=new THREE.Mesh(new THREE.CylinderGeometry(.105,.105,.28,12),chrome);hub.rotation.z=Math.PI/2;wg.add(hub);g.userData.wheels??=[];g.userData.wheels.push(wg);}}
 box(g,0,.62,-2.31,1.15,.28,.09,chrome);box(g,0,.64,-2.37,.78,.16,.035,M(0x151a1d));for(let i=0;i<6;i++)box(g,0,.58+i*.012,-2.395,.72,.012,.012,chrome);
 const headMat=new THREE.MeshStandardMaterial({color:0xfff1d2,emissive:0xffd58a,emissiveIntensity:.9,roughness:.2});for(const side of [-1,1]){box(g,side*.73,.91,-2.32,.48,.27,.09,headMat);box(g,side*.73,.88,2.31,.50,.27,.09,new THREE.MeshStandardMaterial({color:0xc22f27,emissive:0x5d0805,emissiveIntensity:.5}));box(g,side*.88,.42,-2.32,.35,.12,.10,chrome);box(g,side*.88,.42,2.32,.35,.12,.10,chrome)}box(g,0,.40,-2.34,1.95,.16,.16,chrome);box(g,0,.40,2.34,1.95,.16,.16,chrome);box(g,0,.20,0,1.8,.12,3.6,M(0x252a2d));if(policeCar){box(g,0,1.76,0,.8,.16,.38,M(0x315eaa));box(g,-.43,1.76,0,.32,.16,.38,M(0xb43d3d))}return g;
}
const carColors=[0x3d7095,0xb74e3e,0xc2a05b,0x4d705c,0x9a9da0,0x5d536e,0xd1d0c7];
const parkedSpots=[[-8,9,0],[14,-14,Math.PI/2],[-30,-9,0],[30,28,Math.PI],[55,-30,Math.PI/2],[-95,98,0],[180,-95,Math.PI/2]];
for(let i=0;i<parkedSpots.length;i++){const p=parkedSpots[i];cars.push(makeCar(carColors[i%carColors.length],p[0],p[1],p[2]))}
// Traffic cars follow long avenue loops; they are independent of the player's car.
for(let i=0;i<12;i++){
 const horizontal=i%2===0, lane=(Math.floor(i/2)%3-1)*3.2;
 const obj=makeCar(carColors[(i+2)%carColors.length],horizontal?-280+rand()*560:lane,horizontal?lane:-280+rand()*560,horizontal?Math.PI/2:0);
 traffic.push({obj,horizontal,dir:rand()>.5?1:-1,speed:8+rand()*7});
}

// BUILD 09 audio: locally bundled original CC0-dedicated music and sound effects.
const radioAudio=new Audio('audio/retro-fm.mp3');radioAudio.loop=true;radioAudio.volume=.24;radioAudio.preload='auto';
const cityAudio=new Audio('audio/city-ambience.mp3');cityAudio.loop=true;cityAudio.volume=.20;cityAudio.preload='auto';
const engineAudio=new Audio('audio/engine-loop.mp3');engineAudio.loop=true;engineAudio.volume=.08;engineAudio.preload='auto';
const footAudio=new Audio('audio/footsteps.mp3');footAudio.volume=.28;footAudio.preload='auto';
let radioEnabled=true,radioPlaying=false,footstepClock=0,audioUnlocked=false;
function initGameAudio(){audioUnlocked=true;[cityAudio].forEach(a=>{a.play().catch(()=>{})});syncRadio();syncEngine()}
function startRadio(){if(radioPlaying||!radioEnabled||!driving)return;radioAudio.currentTime=radioAudio.currentTime||0;radioAudio.play().then(()=>{radioPlaying=true;document.getElementById('radioStatus').textContent='RETRO FM · CC0 SYNTHWAVE'}).catch(()=>{document.getElementById('radioStatus').textContent='RETRO FM · TIPPE ERNEUT'})}
function stopRadio(){radioAudio.pause();radioPlaying=false;document.getElementById('radioStatus').textContent='RETRO FM · PAUSIERT'}
function syncRadio(){if(driving&&radioEnabled)startRadio();else stopRadio()}
function syncEngine(){if(driving){engineAudio.play().catch(()=>{});engineAudio.volume=Math.min(.18,.055+Math.abs(carSpeed)/34*.09)}else{engineAudio.pause();engineAudio.currentTime=0}}
function updateGameAudio(dt,moving){if(!audioUnlocked)return;if(driving){if(engineAudio.paused)syncEngine();engineAudio.volume=Math.min(.19,.06+Math.abs(carSpeed)/34*.11)}else{if(moving){footstepClock-=dt;if(footstepClock<=0){footAudio.currentTime=0;footAudio.play().catch(()=>{});footstepClock=run?.34:.48}}else footstepClock=0}}
function pauseAllGameAudio(){radioAudio.pause();cityAudio.pause();engineAudio.pause();radioPlaying=false}

let activeCar=null,driving=false,carSpeed=0,yaw=0,pitch=.12,health=100,cash=2450,wanted=0,police=[],shots=[],fire=false,run=false,lastShot=0,toastTimer=0,walkPhase=0,worldClock=0;
const keys={};addEventListener('keydown',e=>{keys[e.key.toLowerCase()]=true;if(e.key.toLowerCase()==='e')toggleCar();if(e.key===' ')shoot()});addEventListener('keyup',e=>keys[e.key.toLowerCase()]=false);
let move=new THREE.Vector2(),look=new THREE.Vector2();
function bindStick(id,fn){const el=document.getElementById(id),knob=el.querySelector('.knob');let pid=null,start=null;el.addEventListener('pointerdown',e=>{pid=e.pointerId;start={x:e.clientX,y:e.clientY};el.setPointerCapture(pid)});el.addEventListener('pointermove',e=>{if(pid!==e.pointerId)return;let dx=e.clientX-start.x,dy=e.clientY-start.y,L=Math.hypot(dx,dy),s=Math.min(1,62/(L||1));dx*=s;dy*=s;knob.style.transform=`translate(${dx}px,${dy}px)`;fn(dx/62,dy/62)});const end=e=>{if(pid!==e.pointerId)return;pid=null;knob.style.transform='';fn(0,0)};el.addEventListener('pointerup',end);el.addEventListener('pointercancel',end)}
bindStick('left',(x,y)=>move.set(x,y));bindStick('right',(x,y)=>look.set(x,y));
document.getElementById('fire').addEventListener('pointerdown',e=>{fire=true;e.preventDefault()});['pointerup','pointercancel','pointerleave'].forEach(ev=>document.getElementById('fire').addEventListener(ev,()=>fire=false));
document.getElementById('sprint').addEventListener('pointerdown',()=>run=true);['pointerup','pointercancel','pointerleave'].forEach(ev=>document.getElementById('sprint').addEventListener(ev,()=>run=false));
document.getElementById('interact').onclick=toggleCar;
document.getElementById('radio').onclick=()=>{radioEnabled=!radioEnabled;const b=document.getElementById('radio');b.textContent='RETRO FM: '+(radioEnabled?'AN':'AUS');b.classList.toggle('off',!radioEnabled);syncRadio()};
function say(t){document.getElementById('toast').textContent=t;toastTimer=2.2}
function toggleCar(){
 if(!driving){let best=null,dist=6;for(const c of cars){const d=c.position.distanceTo(player.position);if(d<dist){best=c;dist=d}}
  if(best){activeCar=best;driving=true;player.visible=false;carSpeed=0;say('EINGESTIEGEN · MOTOR LÄUFT');syncRadio();syncEngine()}else say('KEIN FAHRZEUG IN DER NÄHE')
 }else{player.position.copy(activeCar.position).add(new THREE.Vector3(2.2,0,0));player.visible=true;driving=false;activeCar=null;carSpeed=0;say('AUSGESTIEGEN');syncRadio();syncEngine()}
}
function shoot(){if(driving||performance.now()-lastShot<280)return;lastShot=performance.now();const dir=new THREE.Vector3(Math.sin(yaw),0,-Math.cos(yaw));const b=new THREE.Mesh(new THREE.SphereGeometry(.075,8,8),M(0xffd16b));b.position.copy(player.position).add(new THREE.Vector3(0,1.45,0));scene.add(b);shots.push({mesh:b,dir,life:1.25})}
function addPolice(){const a=rand()*Math.PI*2;const p=makePerson(player.position.x+Math.cos(a)*40,player.position.z+Math.sin(a)*40,0x233c69);police.push(p)}
function districtName(){const x=player.position.x,z=player.position.z;if(Math.abs(x)<85&&Math.abs(z)<85)return'DOWNTOWN';if(z<-235)return'VESPUCCI BEACH';if(z<-100)return'VES PUCCI';if(x>100)return'EASTSIDE';if(x<-100)return'WESTSIDE';if(z>100)return'INDUSTRIAL'}
function drawRadar(){
 const c=document.getElementById('radar'),g=c.getContext('2d');if(!g)return;
 const W=c.width,H=c.height,cx=W/2,cy=H/2,R=101,range=78;
 g.clearRect(0,0,W,H);g.save();g.beginPath();g.arc(cx,cy,R,0,Math.PI*2);g.clip();
 g.fillStyle='rgba(7,17,27,.88)';g.fillRect(0,0,W,H);
 g.strokeStyle='rgba(220,235,245,.19)';g.lineWidth=1.4;
 for(let r=28;r<=84;r+=28){g.beginPath();g.arc(cx,cy,r,0,Math.PI*2);g.stroke()}
 g.beginPath();g.moveTo(cx-R,cy);g.lineTo(cx+R,cy);g.moveTo(cx,cy-R);g.lineTo(cx,cy+R);g.stroke();
 const origin=driving?activeCar.position:player.position,co=Math.cos(yaw),si=Math.sin(yaw);
 const plot=(obj,color,size)=>{const dx=obj.position.x-origin.x,dz=obj.position.z-origin.z;const x=(dx*co-dz*si)/range*R,y=(dx*si+dz*co)/range*R;if(x*x+y*y<R*R){g.fillStyle=color;g.beginPath();g.arc(cx+x,cy+y,size,0,Math.PI*2);g.fill()}};
 for(const v of cars)if(v!==activeCar)plot(v,'#e7c36e',4);
 for(const t of traffic)plot(t.obj,'#80c7e8',3.5);
 for(const p of police)plot(p.group,'#ff5555',5);
 g.restore();g.fillStyle='#fff1c6';g.beginPath();g.moveTo(cx,cy-11);g.lineTo(cx-7,cy+8);g.lineTo(cx,cy+4);g.lineTo(cx+7,cy+8);g.closePath();g.fill();
 g.strokeStyle='rgba(255,255,255,.75)';g.lineWidth=2;g.beginPath();g.arc(cx,cy,R,0,Math.PI*2);g.stroke();
}
function update(dt){
 worldClock+=dt;const cycle=(worldClock/300)%1;const sunPhase=cycle*Math.PI*2-Math.PI/2;const daylight=THREE.MathUtils.clamp((Math.sin(sunPhase)+.18)/1.18,0,1);skyUniforms.uTime.value=worldClock;skyUniforms.uDay.value=daylight;skyDome.position.copy(camera.position);
 sun.intensity=.18+daylight*2.1;sun.color.setRGB(1,.78+.18*daylight,.62+.32*daylight);
 const nightFactor=1-daylight;
 for(const l of nightLights)l.intensity=nightFactor*1.7;
 for(const b of rooftopBeacons)b.material.opacity=.35+.65*Math.abs(Math.sin(worldClock*4));

 sea.material.color.setHSL(.54,.62,.24+.045*Math.sin(worldClock*.6));sea.position.x=Math.sin(worldClock*.12)*2;
 for(const sig of trafficSignals){const phase=(worldClock+sig.offset)%24;const active=phase<10?0:phase<12?1:2;sig.lamps.forEach((lamp,i)=>{lamp.material.emissiveIntensity=i===active?1.8:.045;lamp.material.color.setHex(i===active?[0xff3434,0xffc43b,0x42e477][i]:0x282d30)})}
 for(const b of birdFlock){b.g.position.x+=b.speed*dt;if(b.g.position.x>390)b.g.position.x=-390;b.g.position.y=b.baseY+Math.sin(worldClock*2+b.phase)*1.8;for(const w of b.wings)w.pivot.rotation.z=Math.sin(worldClock*8+b.phase)*.58*w.side;}sunDisc.position.copy(camera.position).add(new THREE.Vector3(-220,110,-360));sunDisc.visible=daylight>.12;moonDisc.position.copy(camera.position).add(new THREE.Vector3(190,145,-340));moonDisc.visible=daylight<.35;sun.position.set(-90+Math.cos(sunPhase)*35,35+daylight*115,70);sun.intensity=.12+daylight*2.05;sun.color.setRGB(1,.62+.31*daylight,.42+.48*daylight);scene.background.setRGB(.025+.48*daylight,.045+.58*daylight,.09+.62*daylight);scene.fog.color.copy(scene.background);scene.fog.near=daylight?190:95;scene.fog.far=daylight?560:360;
 if(toastTimer>0){toastTimer-=dt;if(toastTimer<=0)document.getElementById('toast').textContent=''}
 if(!driving){
  const forward=new THREE.Vector3(Math.sin(yaw),0,-Math.cos(yaw)),right=new THREE.Vector3(Math.cos(yaw),0,Math.sin(yaw));
  let x=(keys.d?1:0)-(keys.a?1:0)+move.x,y=(keys.s?1:0)-(keys.w?1:0)+move.y;
  const v=right.multiplyScalar(x).add(forward.multiplyScalar(-y));if(v.length()>1)v.normalize();
  const speed=(run||keys.shift?10.5:6.1);player.position.addScaledVector(v,speed*dt);
  if(v.lengthSq()>.01){player.rotation.y=Math.atan2(v.x,v.z);walkPhase+=dt*(run?12:8);playerObj.legs[0].rotation.x=Math.sin(walkPhase)*.65;playerObj.legs[1].rotation.x=-Math.sin(walkPhase)*.65;playerObj.arms[0].rotation.x=-Math.sin(walkPhase)*.4;playerObj.arms[1].rotation.x=Math.sin(walkPhase)*.4}
 }else{
  let a=(keys.w?1:0)-(keys.s?1:0)-move.y;carSpeed+=a*19*dt;carSpeed*=Math.pow(.988,dt*60);carSpeed=THREE.MathUtils.clamp(carSpeed,-12,34);
  activeCar.rotation.y-=((keys.a?1:0)-(keys.d?1:0)+move.x)*dt*1.45*Math.sign(carSpeed||1);
  activeCar.translateZ(-carSpeed*dt);if(activeCar.userData.wheels)for(const w of activeCar.userData.wheels)w.rotation.x+=carSpeed*dt*1.8;
  // basic vehicle-to-vehicle bumping
  for(const other of cars){if(other!==activeCar&&other.position.distanceTo(activeCar.position)<2.7){carSpeed*=-.25;activeCar.translateZ(1.2)}}
 }
 yaw-=look.x*dt*2.2;pitch=THREE.MathUtils.clamp(pitch-look.y*dt*.7,-.18,.55);
 if(fire)shoot();
 // traffic loop
 for(const t of traffic){if(t.obj.userData.wheels)for(const w of t.obj.userData.wheels)w.rotation.x+=t.speed*dt*1.8;if(t.horizontal){t.obj.position.x+=t.dir*t.speed*dt;if(t.obj.position.x>305)t.obj.position.x=-305;if(t.obj.position.x< -305)t.obj.position.x=305}else{t.obj.position.z+=t.dir*t.speed*dt;if(t.obj.position.z>305)t.obj.position.z=-305;if(t.obj.position.z< -305)t.obj.position.z=305}}
 // wandering pedestrians
 for(const p of pedestrians){p.phase+=dt;const step=dt*p.speed;p.obj.group.position.x+=Math.sin(p.dir)*step;p.obj.group.position.z+=Math.cos(p.dir)*step;if(Math.sin(p.phase*0.3)>.995)p.dir+=1.2;p.obj.group.rotation.y=p.dir;p.obj.legs[0].rotation.x=Math.sin(p.phase*5)*.35;p.obj.legs[1].rotation.x=-Math.sin(p.phase*5)*.35}
 // projectiles and wanted system
 for(let i=shots.length-1;i>=0;i--){const s=shots[i];s.mesh.position.addScaledVector(s.dir,55*dt);s.life-=dt;let hit=false;for(let j=pedestrians.length-1;j>=0;j--){if(s.mesh.position.distanceTo(pedestrians[j].obj.group.position.clone().add(new THREE.Vector3(0,1,0)))<1){scene.remove(pedestrians[j].obj.group);pedestrians.splice(j,1);wanted=Math.min(5,wanted+1);hit=true;break}}if(hit||s.life<=0){scene.remove(s.mesh);shots.splice(i,1)}}
 for(const p of police){const d=p.group.position.distanceTo(player.position);if(d>1.8){const v=player.position.clone().sub(p.group.position).normalize();p.group.position.addScaledVector(v,dt*2.9);p.group.rotation.y=Math.atan2(v.x,v.z)}else health=Math.max(0,health-dt*7)}
 if(wanted>0&&police.length<Math.ceil(wanted)*2&&rand()<dt*.2)addPolice();
 wanted=Math.max(0,wanted-dt*.001);
 const target=driving?activeCar.position:player.position;
 const behind=new THREE.Vector3(Math.sin(yaw)*8,4.2+pitch*3,Math.cos(yaw)*8);
 camera.position.lerp(target.clone().add(behind),1-Math.pow(.001,dt));camera.lookAt(target.clone().add(new THREE.Vector3(0,1.3,0)));
 document.getElementById('healthfill').style.width=health+'%';
 document.getElementById('money').textContent='$ '+cash.toLocaleString('en-US');
 document.getElementById('wanted').textContent='★'.repeat(Math.ceil(wanted))+'☆'.repeat(5-Math.ceil(wanted));
 document.getElementById('districtname').textContent=districtName()||'OUTSKIRTS';
 drawRadar();
 document.getElementById('speed').textContent=driving?`FAHRT · ${Math.round(Math.abs(carSpeed)*4)} KM/H`:'ZU FUSS';
 updateGameAudio(dt,!driving&&(move.lengthSq()>.015||keys.w||keys.a||keys.s||keys.d));
}
let last=performance.now(),running=false;
function loop(t){if(!running)return;const dt=Math.min(.04,(t-last)/1000);last=t;update(dt);renderer.render(scene,camera);requestAnimationFrame(loop)}
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);renderer.setPixelRatio(Math.min(devicePixelRatio,1.15))});
document.addEventListener('visibilitychange',()=>{if(document.hidden){running=false;pauseAllGameAudio()}else if(!running&&document.getElementById('overlay').style.display==='none'){running=true;last=performance.now();requestAnimationFrame(loop);cityAudio.play().catch(()=>{});syncRadio();syncEngine()}});
window.__bcEngineReady = true;
function startGame(e){
 if(e){e.preventDefault();e.stopPropagation();}
 if(running)return;
 const btn=document.getElementById('start');
 btn.disabled=true;btn.textContent='STADT WIRD GELADEN…';
 try{
  document.getElementById('overlay').style.display='none';
  running=true;last=performance.now();
  renderer.render(scene,camera);
  requestAnimationFrame(loop);
  initGameAudio();
 }catch(err){
  running=false;document.getElementById('overlay').style.display='flex';
  btn.disabled=false;btn.textContent='ERNEUT VERSUCHEN';
  const msg=document.querySelector('#card .small');
  msg.textContent='Startfehler: '+(err?.stack||err?.message||String(err));
 }
}
const startButton=document.getElementById('start');
startButton.addEventListener('pointerup',startGame);
startButton.addEventListener('click',startGame);
startButton.addEventListener('touchend',startGame,{passive:false});
renderer.domElement.addEventListener('pointerdown',e=>{if(e.pointerType==='mouse')renderer.domElement.requestPointerLock?.()});
document.addEventListener('mousemove',e=>{if(document.pointerLockElement===renderer.domElement){yaw-=e.movementX*.003;pitch=THREE.MathUtils.clamp(pitch-e.movementY*.002,-.18,.55)}});
renderer.domElement.addEventListener('click',()=>{if(!('ontouchstart'in window))shoot()});
camera.position.set(0,6,20);camera.lookAt(0,0,0);
