BLACKOUT CITY BUILD 09 — AUDIO / LICENSE NOTES

Bundled files (all stored locally in the APK):
- retro-fm.mp3: original instrumental synthwave composition created for Blackout City; dedicated to CC0 1.0 / public domain. Faster 112 BPM driving beat.
- city-ambience.mp3: original synthesized urban traffic ambience, CC0 1.0.
- engine-loop.mp3: original synthesized idling engine loop, CC0 1.0.
- footsteps.mp3: original synthesized footstep effect, CC0 1.0.

These are original generated audio assets, not recordings or tracks copied from third parties. They are dedicated to the public domain under CC0 1.0. No attribution is required. No GTA music or sound recordings are included.

Playback: city ambience runs while playing; radio starts on entering a car and pauses on exit; radio toggle is available in the HUD; engine loop follows vehicle use; footsteps trigger while walking/running.
