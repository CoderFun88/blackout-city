import numpy as np, wave, os, subprocess
from pathlib import Path
sr=22050
out=Path('/mnt/data/b09work/app/src/main/assets/audio'); out.mkdir(parents=True,exist_ok=True)
rng=np.random.default_rng(9)
def save_wav(name,x):
    x=np.clip(x,-1,1); x=(x*32767).astype('<i2')
    with wave.open(str(out/name),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(sr);w.writeframes(x.tobytes())
def mp3(name,x,bitrate='128k'):
    tmp=out/(name+'.wav');save_wav(tmp.name,x)
    subprocess.run(['ffmpeg','-y','-loglevel','error','-i',str(tmp),'-codec:a','libmp3lame','-b:a',bitrate,str(out/name)],check=True)
    tmp.unlink()
# Original upbeat 112 BPM 80s-inspired synthwave instrumental, ~96 sec
bpm=112; beat=60/bpm; dur=96; n=int(sr*dur); music=np.zeros(n,dtype=np.float32)
def add(sig,t):
    i=int(t*sr); j=min(n,i+len(sig))
    if i<n and j>i: music[i:j]+=sig[:j-i]
def tone(freq,length,amp=.1,kind='sine',decay=3):
    m=int(length*sr); t=np.arange(m)/sr
    if kind=='saw': s=2*((freq*t)%1)-1; s=sum((2*((freq*k*t)%1)-1)/k for k in range(1,5))/2.08
    elif kind=='square': s=np.sign(np.sin(2*np.pi*freq*t))
    else:s=np.sin(2*np.pi*freq*t)
    env=np.exp(-t*decay); return (s*env*amp).astype(np.float32)
def kick():
    t=np.arange(int(.22*sr))/sr; f=48+100*np.exp(-t*28); phase=2*np.pi*np.cumsum(f)/sr
    return (.85*np.sin(phase)*np.exp(-t*17)).astype(np.float32)
def snare():
    m=int(.18*sr);t=np.arange(m)/sr; noise=rng.normal(0,1,m); return (.18*noise*np.exp(-t*22)+.12*np.sin(2*np.pi*185*t)*np.exp(-t*18)).astype(np.float32)
def hat():
    m=int(.055*sr);t=np.arange(m)/sr;return (.07*rng.normal(0,1,m)*np.exp(-t*75)).astype(np.float32)
chords=[[110,164.81,220],[87.31,130.81,174.61],[98,146.83,196],[73.42,110,146.83]]
steps=[0,3,7,10,7,3,5,10]
for bar in range(int(dur/(beat*4))):
    base=bar*beat*4; chord=chords[(bar//2)%4]
    for k in range(4):
        t=base+k*beat; add(kick(),t)
        if k in (1,3):add(snare(),t)
        add(hat(),t+beat*.5);add(hat(),t+beat*1.5)
        # bass eighth-note pulse
        f=chord[0]*(2 if k==2 else 1); add(tone(f,.27,.13,'saw',8),t)
    for j,st in enumerate(steps):
        f=chord[1]*(2**(st/12)); add(tone(f,.24,.055,'square',5),base+j*beat*.5)
    # sustained bright chord every other bar
    if bar%2==0:
        for f in chord:add(tone(f*2,beat*7,.025,'saw',.45),base)
# soft fade and normalize
fade=np.minimum(np.arange(n)/(sr*1.5),1)*np.minimum((n-1-np.arange(n))/(sr*2),1)
music=np.tanh(music*.9)*.62*fade
mp3('retro-fm.mp3',music,'160k')
# 24-sec generated urban ambience: low traffic wash, distant filtered pass-bys, soft city air
D=24; m=int(D*sr); t=np.arange(m)/sr; noise=rng.normal(0,1,m)
# low rumble + broad filtered noise using simple moving average
low=np.convolve(noise,np.ones(900)/900,mode='same')
amb=.035*noise + .24*low
for start in [2.5,7.8,13.1,19.2]:
    length=4.0; ix=int(start*sr); L=int(length*sr); tt=np.arange(L)/sr
    env=np.sin(np.pi*np.clip(tt/length,0,1))**1.5
    carrier=np.sin(2*np.pi*(48+8*np.sin(tt*2))*tt)+.35*np.sin(2*np.pi*92*tt)
    amb[ix:ix+L]+=(.12*env*carrier).astype(np.float32)
amb=np.tanh(amb*2)*.34
mp3('city-ambience.mp3',amb,'96k')
# looping idling engine, layered low motor pulses
D=5; m=int(D*sr);t=np.arange(m)/sr
engine=.16*np.sin(2*np.pi*34*t)+.07*np.sin(2*np.pi*68*t)+.035*np.sin(2*np.pi*102*t)
engine*=.8+.2*np.sin(2*np.pi*3.2*t)
engine+=.018*rng.normal(0,1,m)
# fade edges to loop seamlessly
edge=int(.12*sr); ramp=np.ones(m); ramp[:edge]=np.linspace(0,1,edge);ramp[-edge:]=np.linspace(1,0,edge);engine=np.tanh(engine*2)*ramp*.45
mp3('engine-loop.mp3',engine,'96k')
# footstep double tap, generated short muted concrete-like thuds
D=0.42;m=int(D*sr);t=np.arange(m)/sr;step=np.zeros(m)
for st in [0,.21]:
    ix=int(st*sr);L=m-ix;tt=np.arange(L)/sr
    step[ix:]+=((.55*np.sin(2*np.pi*75*tt)+.3*rng.normal(0,1,L))*np.exp(-tt*24))
step=np.tanh(step*1.2)*.48
mp3('footsteps.mp3',step,'64k')
print([(p.name,p.stat().st_size) for p in out.iterdir() if p.is_file()])
